import pygame, sys
from buttonM import Button
import RPG_Project_V1_2_1
import Enemy_Class
import Weapons
#from RPG_Project_V1_2_1 import Fighter


pygame.init()

#Create the screen and set the window caption

SCREEN = pygame.display.set_mode((800, 550), pygame.RESIZABLE)
pygame.display.set_caption("The Song of the Lost")

#General font imports#

font = pygame.font.Font('Menu_assets/runescape_uf.ttf', 26)
headingfont = pygame.font.SysFont("Verdana", 40)
regularfont = pygame.font.SysFont('Corbel',25)
smallerfont = pygame.font.SysFont('Corbel',16)
bottom_panel_font = pygame.font.Font('Menu_assets/Enchanted Land.otf', 18)
font_pixel = pygame.font.Font('Menu_assets/m5x7.ttf', 26)

#def colors
red = (255, 0, 0)
green = (0, 255, 0)
color_light = (170,170,170)
color_dark = (100,100,100)
color_white = (255,255,255)
black = (0,0,0)


#Set main menu background image

BG = pygame.image.load("Menu_assets/Background1.png")

#Set inventory background and assets

inventory_background = pygame.image.load("Menu_assets/Red Book/3.png")
inventory_background = pygame.transform.scale(inventory_background, (900, 600))

inventory_button_clicked = pygame.image.load("RPG_Project_items/img/Icons/inv_button_clicked.png")
inventory_button_clicked = pygame.transform.scale(inventory_button_clicked, (45, 45))

inventory_exit_button = pygame.image.load("RPG_Project_items/img/Icons/Exit_button.png")
inventory_exit_button = pygame.transform.scale(inventory_exit_button, (45, 45))


#Change pygame icon

WindowIcon = pygame.image.load('RPG_Project_items/img/Icons/potion.png')
pygame.display.set_icon(WindowIcon)

#Import gold and xp values from the main character class#

main_character = RPG_Project_V1_2_1.Fighter(200, 260, 'Knight', 30, 10, 3, 8, 8, 3, 10, 0, 0)


current_xp = main_character.experience
current_gp = main_character.gp

print()

def inventory_book_animation():

    action = 0

    temp_list = []
    for i in range(7):
        img = pygame.image.load(f'Menu_assets/Red Book/{i}.png')
        img = pygame.transform.scale(img, (img.get_width() * 3, img.get_height() * 3))
        temp_list.append(img)
    inventory_book_animation.image = temp_list[0]
    inventory_book_animation.rect = inventory_book_animation.image.get_rect()
    inventory_book_animation.rect.center = (100, 100)



def show_XP(x, y):
    xp = font_pixel.render("Current Experience: " + str(current_xp), True, color_white)
    SCREEN.blit(xp, (x, y))

def show_GP(x, y):
    gp = font_pixel.render("Current Gold: " + str(current_gp), True, color_white)
    SCREEN.blit(gp, (x, y))


def menu():
    main_menu()

if __name__ == "__menu__":
    menu()

def get_font(size): # Returns Press-Start-2P in the desired size
    return pygame.font.Font("Menu_assets/runescape_uf.ttf", size)

def play():
    while True:
        PLAY_MOUSE_POS = pygame.mouse.get_pos()

        SCREEN.fill("black")

        RPG_Project_V1_2_1.main()

        PLAY_TEXT = get_font(45).render("This is the PLAY screen.", True, "White")
        PLAY_RECT = PLAY_TEXT.get_rect(center=(640, 260))
        SCREEN.blit(PLAY_TEXT, PLAY_RECT)

        PLAY_BACK = Button(image=None, pos=(640, 460), 
                            text_input="BACK", font=get_font(75), base_color="White", hovering_color="Green")

        PLAY_BACK.changeColor(PLAY_MOUSE_POS)
        PLAY_BACK.update(SCREEN)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if PLAY_BACK.checkForInput(PLAY_MOUSE_POS):
                    main_menu()

        pygame.display.update()
    
def options():
    while True:
        OPTIONS_MOUSE_POS = pygame.mouse.get_pos()

        SCREEN.fill("white")

        OPTIONS_TEXT = get_font(45).render("The Lush Life is Giving Me a Rush!", True, "Black")
        OPTIONS_RECT = OPTIONS_TEXT.get_rect(center=(400, 225))
        SCREEN.blit(OPTIONS_TEXT, OPTIONS_RECT)

        OPTIONS_BACK = Button(image=None, pos=(640, 460), 
                            text_input="BACK", font=get_font(75), base_color="Black", hovering_color="Green")

        OPTIONS_BACK.changeColor(OPTIONS_MOUSE_POS)
        OPTIONS_BACK.update(SCREEN)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if OPTIONS_BACK.checkForInput(OPTIONS_MOUSE_POS):
                    main_menu()

        pygame.display.update()

#def

def main_menu():
    title_track = pygame.mixer.music.load("Music/Intro/Intro_test_1.wav")
    play_title = False
    if play_title == False:
        pygame.mixer.music.stop()
    elif play_title == True:
        pygame.mixer.music.play(-1)

    while True:
        SCREEN.blit(BG, (0, 0))

        MENU_MOUSE_POS = pygame.mouse.get_pos()

        MENU_TEXT = get_font(60).render("The Song of the Lost", True, "#b68f40")
        MENU_RECT = MENU_TEXT.get_rect(center=(400, 100))

        PLAY_BUTTON = Button(image=pygame.image.load("RPG_Project_items/img/Icons/Button_background.png"), pos=(400, 200), 
                            text_input="PLAY", font=get_font(35), base_color="#d7fcd4", hovering_color="White")
        OPTIONS_BUTTON = Button(image=pygame.image.load("RPG_Project_items/img/Icons/Button_background.png"), pos=(400, 325), 
                            text_input="OPTIONS", font=get_font(35), base_color="#d7fcd4", hovering_color="White")
        QUIT_BUTTON = Button(image=pygame.image.load("RPG_Project_items/img/Icons/Button_background.png"), pos=(400, 450), 
                            text_input="QUIT", font=get_font(35), base_color="#d7fcd4", hovering_color="White")

        SCREEN.blit(MENU_TEXT, MENU_RECT)

        for button in [PLAY_BUTTON, OPTIONS_BUTTON, QUIT_BUTTON]:
            button.changeColor(MENU_MOUSE_POS)
            button.update(SCREEN)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if PLAY_BUTTON.checkForInput(MENU_MOUSE_POS):
                    play()
                if OPTIONS_BUTTON.checkForInput(MENU_MOUSE_POS):
                    options()
                if QUIT_BUTTON.checkForInput(MENU_MOUSE_POS):
                    pygame.quit()
                    sys.exit()

        pygame.display.update()

def inventory():

    inventory_book_animation()

    while True:
        SCREEN.blit(inventory_background, (-30, -80))
        SCREEN.blit(inventory_button_clicked, (225, 473))

        MENU_MOUSE_POS = pygame.mouse.get_pos()

        MENU_TEXT = get_font(60).render("inventory", True, "#d7fcd4")
        MENU_RECT = MENU_TEXT.get_rect(center=(400, 50))

        PLAY_BUTTON = Button(image=(inventory_exit_button), pos=(690, 60), 
                            text_input="", font=get_font(35), base_color="#d7fcd4", hovering_color="White")

        show_XP(100, 250)
        show_GP(100, 300)

        SCREEN.blit(MENU_TEXT, MENU_RECT)

        for button in [PLAY_BUTTON]:
            button.changeColor(MENU_MOUSE_POS)
            button.update(SCREEN)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if PLAY_BUTTON.checkForInput(MENU_MOUSE_POS):
                    play()


        pygame.display.update()

menu()